import React, { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { CONFIG, COLORS } from '../constants';
import { AppState } from '../types';
import { useStore } from '../store';

const vertexShader = `
  uniform float uTime;
  uniform float uProgress;
  uniform float uPixelRatio;
  
  attribute vec3 chaosPosition;
  attribute vec3 targetPosition;
  attribute float aScale;
  attribute float aSpeed;
  
  varying vec3 vColor;
  
  void main() {
    // Cubic bezier ease-in-out approximation for smooth transition
    float t = uProgress;
    float smoothT = t * t * (3.0 - 2.0 * t);
    
    // Interpolate positions
    vec3 pos = mix(targetPosition, chaosPosition, smoothT);
    
    // Add some subtle wind/breathing movement when formed
    if (uProgress < 0.1) {
      pos.x += sin(uTime * aSpeed + pos.y) * 0.05;
      pos.z += cos(uTime * aSpeed + pos.y) * 0.05;
    }

    // Add chaos noise when unleashed
    if (uProgress > 0.9) {
      pos.x += sin(uTime * 5.0 * aSpeed) * 0.1;
      pos.y += cos(uTime * 5.0 * aSpeed) * 0.1;
    }

    vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
    gl_Position = projectionMatrix * mvPosition;
    
    gl_PointSize = aScale * 40.0 * uPixelRatio;
    gl_PointSize *= (1.0 / -mvPosition.z);
    
    // Color gradient based on height
    vec3 colorTop = vec3(0.0, 0.42, 0.23); // Emerald
    vec3 colorBot = vec3(0.0, 0.20, 0.10); // Deep Dark
    vColor = mix(colorBot, colorTop, (pos.y + 6.0) / 12.0);
  }
`;

const fragmentShader = `
  varying vec3 vColor;
  
  void main() {
    // Circular particle
    vec2 cxy = 2.0 * gl_PointCoord - 1.0;
    float r = dot(cxy, cxy);
    if (r > 1.0) discard;
    
    // Soft glow edge
    float alpha = 1.0 - smoothstep(0.5, 1.0, r);
    
    gl_FragColor = vec4(vColor, alpha);
  }
`;

export const Foliage: React.FC = () => {
  const mode = useStore((state) => state.mode);
  const meshRef = useRef<THREE.Points>(null);
  const materialRef = useRef<THREE.ShaderMaterial>(null);
  
  // Animation state (0 = Formed, 1 = Chaos)
  const animProgress = useRef(0);

  const { particles, chaosPositions, targetPositions, scales, speeds } = useMemo(() => {
    const count = CONFIG.PARTICLE_COUNT;
    const chaosPos = new Float32Array(count * 3);
    const targetPos = new Float32Array(count * 3);
    const scaleArr = new Float32Array(count);
    const speedArr = new Float32Array(count);

    for (let i = 0; i < count; i++) {
      // 1. Target Position (Cone)
      // Normalized height 0 to 1
      const yNorm = Math.random(); 
      const y = (yNorm - 0.5) * CONFIG.TREE_HEIGHT;
      // Radius decreases as we go up
      const r = (1 - yNorm) * CONFIG.TREE_RADIUS * Math.sqrt(Math.random()); // sqrt for uniform distribution
      const theta = Math.random() * Math.PI * 2;
      
      targetPos[i * 3] = r * Math.cos(theta);
      targetPos[i * 3 + 1] = y;
      targetPos[i * 3 + 2] = r * Math.sin(theta);

      // 2. Chaos Position (Random Sphere)
      const u = Math.random();
      const v = Math.random();
      const theta2 = 2 * Math.PI * u;
      const phi = Math.acos(2 * v - 1);
      const r2 = 15 + Math.random() * 10; // Large radius scatter
      
      chaosPos[i * 3] = r2 * Math.sin(phi) * Math.cos(theta2);
      chaosPos[i * 3 + 1] = r2 * Math.sin(phi) * Math.sin(theta2);
      chaosPos[i * 3 + 2] = r2 * Math.cos(phi);

      scaleArr[i] = Math.random() * 0.5 + 0.5;
      speedArr[i] = Math.random() * 0.5 + 0.5;
    }

    return { 
      particles: count, 
      chaosPositions: chaosPos, 
      targetPositions: targetPos, 
      scales: scaleArr,
      speeds: speedArr 
    };
  }, []);

  useFrame((state, delta) => {
    if (materialRef.current) {
      materialRef.current.uniforms.uTime.value = state.clock.elapsedTime;
      materialRef.current.uniforms.uPixelRatio.value = Math.min(window.devicePixelRatio, 2);

      // Lerp logic
      const target = mode === AppState.CHAOS ? 1 : 0;
      animProgress.current = THREE.MathUtils.lerp(animProgress.current, target, delta * CONFIG.ANIMATION_SPEED);
      materialRef.current.uniforms.uProgress.value = animProgress.current;
    }
  });

  return (
    <points ref={meshRef}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-targetPosition" count={particles} array={targetPositions} itemSize={3} />
        <bufferAttribute attach="attributes-chaosPosition" count={particles} array={chaosPositions} itemSize={3} />
        <bufferAttribute attach="attributes-aScale" count={particles} array={scales} itemSize={1} />
        <bufferAttribute attach="attributes-aSpeed" count={particles} array={speeds} itemSize={1} />
        <bufferAttribute attach="attributes-position" count={particles} array={targetPositions} itemSize={3} />
      </bufferGeometry>
      <shaderMaterial
        ref={materialRef}
        vertexShader={vertexShader}
        fragmentShader={fragmentShader}
        uniforms={{
          uTime: { value: 0 },
          uProgress: { value: 0 },
          uPixelRatio: { value: 1 },
        }}
        transparent
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
};
